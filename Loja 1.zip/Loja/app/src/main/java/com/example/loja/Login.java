package com.example.loja;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        final Vibrator vb =(Vibrator)
                Login.this.getSystemService(Context.VIBRATOR_SERVICE);
        final Button botao = (Button)findViewById(R.id.buttonaa);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
                NotificationChannel channel = new NotificationChannel("Minha ntf", "Minha ntf", NotificationManager.IMPORTANCE_DEFAULT);
                NotificationManager manager = getSystemService(NotificationManager.class);
                manager.createNotificationChannel(channel);
}


        botao.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View view) {
                vb.vibrate(500);

                NotificationManager mm=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                PendingIntent p = PendingIntent.getActivity(Login.this, 0, new Intent(Login.this, MainActivity.class), 0 );

                NotificationCompat.Builder builder = new NotificationCompat.Builder(Login.this, "Minha ntf");
                builder.setTicker("Mundo Games");
                builder.setContentTitle("Você realizou login com sucesso");
                builder.setContentText("Boas compras!");
                builder.setSmallIcon(R.drawable.jogo);
                builder.setAutoCancel(true);
                builder.setContentIntent(p);
                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(Login.this);
                managerCompat.notify(1, builder.build());
                finish();

            }
        });

    }

    public void intenthome(View view) {
        Intent i2 = new Intent(Login.this, MainActivity.class);
        startActivity(i2);
    }

    public void abrirCamera(View v){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivity(intent);
    }

    /*public void notificacao(){
        NotificationManager mm=(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        PendingIntent p = PendingIntent.getActivity(Login.this, 0, new Intent(Login.this, MainActivity.class), 0 );
        NotificationCompat.Builder builder = new NotificationCompat.Builder(Login.this, "Minha ntf");
        builder.setTicker("Mundo Games");
        builder.setContentTitle("Você realizou login com sucesso");
        builder.setContentText("Boas compras!");
        builder.setSmallIcon(R.drawable.ic_launcher_background);
        builder.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher_background));
        builder.setContentIntent(p);
        Notification n = builder.build();
        mm.notify(R.drawable.ic_launcher_background, n); //código certo porém não envia notificacao no android oreo, adaptado para funcionar em meu cel acima.
    }*/

}