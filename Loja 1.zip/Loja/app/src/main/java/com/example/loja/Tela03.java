package com.example.loja;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Tela03 extends AppCompatActivity {
    ImageView img;
    TextView titulo, preco;
    Button botao;
    private ListView listaSobre;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela03);
        getSupportActionBar().hide();
        img = (ImageView) findViewById(R.id.imageView1);
        titulo = (TextView) findViewById(R.id.textView1);
        preco = (TextView) findViewById(R.id.textView3);
        botao = (Button) findViewById(R.id.buttonaa);
        Bundle b = getIntent().getExtras();
        int valor = b.getInt("valor");

        switch (valor) {
            case 1:
                titulo.setText(R.string.p_aranha);
                img.setImageResource(R.drawable.aranha);
                preco.setText(R.string.v_aranha);
                break;
            case 2:
                titulo.setText(R.string.p_fifa);
                img.setImageResource(R.drawable.fifa);
                preco.setText(R.string.v_fifa);
                break;
            case 3:
                titulo.setText(R.string.p_gta5);
                img.setImageResource(R.drawable.gta5);
                preco.setText(R.string.v_gta5);
                break;
            case 4:
                titulo.setText(R.string.p_mine);
                img.setImageResource(R.drawable.mine);
                preco.setText(R.string.v_mine);
                break;

            case 5:
                titulo.setText(R.string.p_crash);
                img.setImageResource(R.drawable.crash);
                preco.setText(R.string.v_crash);
                break;
            case 6:
                titulo.setText(R.string.p_god);
                img.setImageResource(R.drawable.god);
                preco.setText(R.string.v_god);
                break;
            case 7:
                titulo.setText(R.string.p_kart);
                img.setImageResource(R.drawable.kart);
                preco.setText(R.string.v_kart);
                break;
            case 8:
                titulo.setText(R.string.p_mario);
                img.setImageResource(R.drawable.mario);
                preco.setText(R.string.v_mario);
                break;

            default:
                break;
        }


        //ListView
        String sobre[] = {"Seu pagamento é 100% seguro","Frete grátis para compras a partir de R$149,90 válido para todo o Brasil","SAC 0800-110-1111","Mundo Games LTDA CNPJ 11.111.111-0001-11"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,sobre);
        listaSobre = (ListView) findViewById(R.id.listView1);
        listaSobre.setAdapter(adapter);




    }
    public void intent(View view) {
        Intent i = new Intent(Tela03.this, Tela04.class);
        startActivity(i);
    }
    public void intenthome(View view) {
        Intent i2 = new Intent(Tela03.this, MainActivity.class);
        startActivity(i2);
    }

}