package com.example.loja;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher;

import com.google.android.material.animation.AnimationUtils;

public class MainActivity extends AppCompatActivity {
    ImageSwitcher im;

    int i=1;
    Bundle b = new Bundle();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();
        NotificationManager mm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        mm.cancel(R.drawable.game);
        im=(ImageSwitcher) findViewById(R.id.imageSwitcher1);



        im.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView myView = new ImageView(getApplicationContext());
                myView.setScaleType(ImageView.ScaleType.FIT_CENTER);

                return myView;

            }

        });



    }
    public void cliqueb1(View v){
        switch (i){

            case 1:
                i++;
                im.setImageResource(R.drawable.i2);
                break;
            case 2:
                i++;
                im.setImageResource(R.drawable.i3);
                break;
            case 3:
                i++;
                im.setImageResource(R.drawable.i4);
                break;
            case 4:
                i++;
                im.setImageResource(R.drawable.i5);
                break;
            default:

                im.setImageResource(R.drawable.i1);
                i=1;
                break;
        }

    }


    public void cliqueb2(View v){
        switch (i){

            case 1:
                i++;
                im.setImageResource(R.drawable.i4);
                break;
            case 2:
                i++;
                im.setImageResource(R.drawable.i3);
                break;
            case 3:
                i++;
                im.setImageResource(R.drawable.i2);
                break;
            case 4:
                i++;
                im.setImageResource(R.drawable.i5);
                break;
            default:

                im.setImageResource(R.drawable.i1);
                i=1;
                break;
        }


    }

    public void aranha(View view) {
        b.putInt("valor", 1);
        Intent v1=new Intent(MainActivity.this,Tela03.class);
        v1.putExtras(b);
        startActivity(v1);

    }
    public void fifa(View view) {
        b.putInt("valor", 2);
        Intent v2=new Intent(MainActivity.this,Tela03.class);
        v2.putExtras(b);
        startActivity(v2);

    }

    public void gta5(View view) {
        b.putInt("valor", 3);
        Intent v3=new Intent(MainActivity.this,Tela03.class);
        v3.putExtras(b);
        startActivity(v3);

    }

    public void mine(View view) {
        b.putInt("valor", 4);
        Intent v4=new Intent(MainActivity.this,Tela03.class);
        v4.putExtras(b);
        startActivity(v4);

    }


    public void crash(View view) {
        b.putInt("valor", 5);
        Intent v5=new Intent(MainActivity.this,Tela03.class);
        v5.putExtras(b);
        startActivity(v5);

    }
    public void god(View view) {
        b.putInt("valor", 6);
        Intent v6=new Intent(MainActivity.this,Tela03.class);
        v6.putExtras(b);
        startActivity(v6);

    }

    public void kart(View view) {
        b.putInt("valor", 7);
        Intent v7=new Intent(MainActivity.this,Tela03.class);
        v7.putExtras(b);
        startActivity(v7);

    }

    public void mario(View view) {
        b.putInt("valor", 8);
        Intent v8=new Intent(MainActivity.this,Tela03.class);
        v8.putExtras(b);
        startActivity(v8);

    }








    public void fazerLogin(View view){
        Intent v5=new Intent(MainActivity.this, Login.class);
        startActivity(v5);
    }
}