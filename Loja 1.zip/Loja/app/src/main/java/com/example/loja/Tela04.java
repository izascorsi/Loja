package com.example.loja;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class Tela04 extends AppCompatActivity {
    EditText c1,c2;

    RadioGroup grupo;
    RatingBar r;
    TextView texto;
    int marcou;
    TextView preco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();


        setContentView(R.layout.activity_tela04);
        c1 = (EditText) findViewById(R.id.editText1);
        c2 = (EditText)findViewById(R.id.editText2);
        texto = (TextView)findViewById(R.id.textView2);
        grupo = (RadioGroup)findViewById(R.id.radioGroup1);



    grupo.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup radioGroup, int arg1) {
            switch (grupo.getCheckedRadioButtonId()) {
                case R.id.radio0:
                    marcou=0;
                    break;
                case R.id.radio1:
                    marcou=1;
                    break;
                case R.id.radio2:
                    marcou=2;
                    break;
                case R.id.radio3:
                    marcou=3;
                    break;
                case R.id.radio4:
                    marcou=4;
                    break;
                default:
                    break;
            }


        }
    });
    }




    public void intenthome(View view) {
        Intent i2 = new Intent(Tela04.this, MainActivity.class);
        startActivity(i2);
    }

    public void metodo(View view) {

        double valor, qtd, t;
        try {
            valor=Double.parseDouble(c1.getText().toString());
            qtd=Double.parseDouble(c2.getText().toString());

            t=valor*qtd;
            switch (marcou) {
                case 0:
                    t=t;
                    break;
                case 1:
                    t=t-(t*0.05);
                    break;
                case 2:
                    t=t+(t*0.10);
                    break;
                case 3:
                    t=t+(t*0.15);
                    break;
                case 4:
                    t=t-(t*0.05);
                    break;

            }
            texto.setText("Valor total a ser pago: "+t);




        //catch



        } catch (Exception e) {
// TODO: handle exception
            Toast.makeText(Tela04.this,
                    "Valor inválido: ",
                    Toast.LENGTH_SHORT).show();
        }
    }

}